# Headings

Alternate Syntax
----------------

**Bold some**. *Italic some*. Come `code some`.
Escape \* \` \< \_ \# \\ & more.

1. Ordered list

- Unordered list ( - or + )

> Blockquote

```
npx markdown-plus-plus --help
```

URL: [It's open source][1] | image: ![2][]

[1]: https://github.com/Edditoria/markdown-plus-plus
[2]: ../docs/images/markdown-plus-plus-social-preview.png

<!-- Welcome comments, issue and pull request -->

Enjoy! :)
